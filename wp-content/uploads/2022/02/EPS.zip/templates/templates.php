<?php theme_register_template('Blog Template', 'blogTemplate', 'templates/blog.php'); ?>
<?php theme_register_template('Post Template', 'postTemplate', 'templates/post.php'); ?>
<?php theme_register_template('404 Template', 'page404Template', 'templates/page404.php'); ?>
<?php theme_register_template('Login Template', 'pageLoginTemplate', 'templates/pageLogin.php'); ?>