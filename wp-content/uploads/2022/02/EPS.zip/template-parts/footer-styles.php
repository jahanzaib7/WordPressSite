<!-- footer styles -->

<style> .u-footer {
  background-image: none;
}
.u-footer .u-sheet-1 {
  min-height: 81px;
}
.u-footer .u-text-1 {
  width: 483px;
  margin: 28px auto 29px;
}
@media (max-width: 1199px) {
  .u-footer .u-sheet-1 {
    min-height: 99px;
  }
  .u-footer .u-text-1 {
    width: 483px;
    font-size: 0.875rem;
  }
}
@media (max-width: 991px) {
  .u-footer .u-sheet-1 {
    min-height: 76px;
  }
}
@media (max-width: 767px) {
  .u-footer .u-sheet-1 {
    min-height: 57px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-sheet-1 {
    min-height: 36px;
  }
  .u-footer .u-text-1 {
    width: 340px;
  }
}</style>
